# Play Audio in Xamarin Forms | Complete Music Player App
Learn how to design a COMPLETE Music Player in Xamarin Forms. In this video, we will make use of the Media Manager Plugin to make a music player app in Xamarin Forms and at the end you will see that music player in xamarin forms in quite easy.

You can watch the video here ➤ https://youtu.be/7plenjrcloM


![alt text](https://devcrux.com/wp-content/uploads/MusicPlayer-Thumbnail.png) 
